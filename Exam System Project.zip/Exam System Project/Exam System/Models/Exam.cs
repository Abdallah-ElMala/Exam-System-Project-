﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exam_Project.ENums;
using static Exam_Project.Models.ExamEventArgs;

namespace Exam_Project.Models
{
    public abstract class Exam : ICloneable, IComparable<Exam>
    {
        public int Time { get; set; } // Time in minutes
        public int NumberOfQuestions { get; set; }
        public ExamMode Mode { get; private set; } = ExamMode.Queued;
        public Subject Subject { get; set; }

        public Dictionary<Questions, List<int>> QuestionAnswerDictionary { get; set; }

        public event ExamStartedEventHandler ExamStarted;
        public Exam(int time, int _NumberOfQuestions, Subject subject)
        {
            Time = time;
            NumberOfQuestions = _NumberOfQuestions;
            Subject = subject;
            QuestionAnswerDictionary = new Dictionary<Questions, List<int>>();
        }
        public void StartExam()
        {
            Mode = ExamMode.Starting;
            OnExamStarted(new ExamEventArgs { SubjectName = Subject?.SubjectName ?? "N/A", StartTime = DateTime.Now });
        }
        protected virtual void OnExamStarted(ExamEventArgs e)
        {
            ExamStarted?.Invoke(this, e);
        }

        public void FinishExam()
        {
            Mode = ExamMode.Finished;
        }

        public abstract void ShowExam();
        public abstract object Clone();

        public int CompareTo(Exam other) => Time.CompareTo(other?.Time ?? 0);
    }
}
