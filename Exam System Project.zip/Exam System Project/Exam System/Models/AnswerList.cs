﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam_Project.Models
{
    public class AnswerList : List<Answer>
    {
        public void DisplayAnswers()
        {
            foreach (var answer in this)
            {
                Console.WriteLine(answer);
            }
        }
    }
}
