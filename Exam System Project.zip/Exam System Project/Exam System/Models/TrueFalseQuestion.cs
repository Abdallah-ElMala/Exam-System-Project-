﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;

namespace Exam_Project.Models
{
    public class TrueFalseQuestion : Questions
    {
        public TrueFalseQuestion(string header, string body, int marks, AnswerList answerList)
            : base(header, body, marks, answerList) { }

        public override object Clone()
        {
            return new TrueFalseQuestion(head, body, marks, Answers);
        }
    }
}
