﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam_Project.Models
{
    public class Answer : IEquatable<Answer>
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public Answer(int id,string name)
        {
            Id= id;
            Name= name;
        }
        public bool Equals(Answer other)
        {
           if (other == null) return false;
           return (this.Id ==other.Id) ;
        }
        public override bool Equals(object obj)
        {
            return Equals(obj as Answer);
        }
        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }
        public override string ToString()
        {
            return $" {Id}) {Name}";
        }
    }
}
