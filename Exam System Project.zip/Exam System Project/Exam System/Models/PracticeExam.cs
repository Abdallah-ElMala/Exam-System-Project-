﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam_Project.Models
{
    public class PracticeExam : Exam
    {
        public PracticeExam(int time, int numberOfQuestions, Subject subject)
            : base(time, numberOfQuestions, subject) { }

        public override void ShowExam()
        {
            Console.WriteLine($"\n--- Starting Practice Exam: {Subject.SubjectName} ---");
            Console.WriteLine($"Exam Duration : {Time} Minutes");
            int totalGrade = 0;
            int maxGrade = 0;

            foreach (var kvp in QuestionAnswerDictionary)
            {
                Questions q = kvp.Key;
                List<int> correctAnswers = kvp.Value;
                maxGrade += q.marks;

                Console.WriteLine($"\n{q}");
                q.Answers.DisplayAnswers();

                Console.Write("Your Answer ID(s) [separated by comma if multiple]: ");
                string input = Console.ReadLine();

                List<int> userAnswers = new List<int>();
                foreach (var item in input.Split(','))
                {
                    if (int.TryParse(item.Trim(), out int val))
                        userAnswers.Add(val);
                }

                // Check correctness
                userAnswers.Sort();
                List<int> sortedCorrect = new List<int>(correctAnswers);
                sortedCorrect.Sort();

                bool isCorrect = userAnswers.Count == sortedCorrect.Count;
                if (isCorrect)
                {
                    for (int i = 0; i < userAnswers.Count; i++)
                    {
                        if (userAnswers[i] != sortedCorrect[i]) { isCorrect = false; break; }
                    }
                }

                if (isCorrect) totalGrade += q.marks;

                // Practice Exam Feature: Reveal correct answer immediately or at the end
                Console.WriteLine($"[Correct Answer ID(s): {string.Join(", ", sortedCorrect)}]");
            }

            FinishExam();
            Console.WriteLine($"\nPractice Exam Finished! Grade: {totalGrade}/{maxGrade}");
        }

        public override object Clone() => new PracticeExam(Time, NumberOfQuestions, Subject);
    }
        
}

