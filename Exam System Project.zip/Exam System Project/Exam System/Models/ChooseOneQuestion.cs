﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam_Project.Models
{
    public class ChooseOneQuestion : Questions
    {
        public ChooseOneQuestion(string header, string body, int marks, AnswerList answerList)
          : base(header, body, marks, answerList) { }

        public override object Clone()
        {
            return new ChooseOneQuestion(head, body, marks, Answers);
        }
    }
}
