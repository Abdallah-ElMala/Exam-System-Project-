﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;

namespace Exam_Project.Models
{
    public abstract class Questions : ICloneable, IComparable<Questions>
    {
        public string head {  get; set; }
        public string body { get; set; }
        public int marks {  get; set; }
        public AnswerList Answers {  get; set; }

        public Questions(): this("Question" ," " ,1 , new AnswerList()) { }
        public Questions(string _head, string _body,int _marks, AnswerList _Answers)
        {
            head = _head;
            body = _body;
            marks = _marks;
            Answers = _Answers;
        }

        
        public abstract object Clone();
        public int CompareTo(Questions other) => marks.CompareTo(other?.marks ?? 0);
        public override string ToString()
        {
            return $"[{head}] (Marks: {marks})\n{body}";
        }
        public override bool Equals(object obj)
        {
            return obj is Questions q && head == q.head && body == q.body && marks == q.marks;
        }

        public override int GetHashCode() => HashCode.Combine(head, body, marks);


    }

   
}
